<?php namespace App\Controllers\dashboard;
use App\Controllers\BaseController;

class CategoryController extends BaseController {

    public function index(){
        echo "Hola mundo";
    }


}