<?php namespace App\Controllers\dashboard;
use App\Models\MovieModel;
use App\Controllers\BaseController;

class MovieController extends BaseController {

    public function index(){

        $dataHeader =[
            'title' => 'Listado de películas'
        ];

        $data = [
            'movies' => array(0,1,2,3,4)
        ];

        echo view("dashboard/templates/header",$dataHeader);
        echo view("dashboard/movie/index",$data);
        echo view("dashboard/templates/footer");
    }

    public function test($name = "andres"){

        $dataHeader =[
            'title' => 'Listado de películas '.$name 
        ];

        $data = [
            'movies' => array(0,1,2,3,4)
        ];

        echo view("dashboard/templates/header",$dataHeader);
        echo view("dashboard/movie/index",$data);
        echo view("dashboard/templates/footer");
    }

    public function show(){
        
        $movie = new MovieModel();

        var_dump($movie->get(7)['id']);

    }


}