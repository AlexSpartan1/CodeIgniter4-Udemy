<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CodeIgniter</title>
</head>
<body>
    <h1>CodeIniger 4!</h1>
</body>
</html>