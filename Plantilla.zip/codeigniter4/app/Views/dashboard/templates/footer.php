<footer>
    Pie de página

    <a href="<?= route_to('contacto','Juan') ?>">Contacto</a>

</footer>

</body>
</html>